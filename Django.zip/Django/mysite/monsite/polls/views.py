from django.shortcuts import render
import pandas as pd
import plotly.express as px


df = pd.read_csv("C:/Projet_python/SkillCraft_Visu.csv")

def index(request):  
    
    monmessage = "Entrer l'url de la page que vous souhaitez consulter :"
    monmessage2 = "'http://127.0.0.1:8000/polls/page1' pour voir la Variable selectionnée en fonction du LeagueIndex."
    monmessage3 = "'http://127.0.0.1:8000/polls/page2' pour voir le Nombre APM en fonction de la variable selectionnée des 1000 premieres lignes de LeagueIndex."

    context = {'monmessage': monmessage,
               'monmessage2' : monmessage2,
               'monmessage3' : monmessage3
                }
               
    return render(request,'templates0.html',context)

def index01(request):  
    

    context = {
        }
               
    return render(request,'templates01.html',context)


def index02(request):  
    

    context = {
        }
               
    return render(request,'templates02.html',context)


def TotalHours():  
    
    temp = df.groupby("LeagueIndex")["TotalHours"].mean()
    fig = px.line(temp,y="TotalHours", title ="TotalHours en fonction du LeagueIndex")
    plot1_html = fig.to_html()
               
    return plot1_html

def APM():  

    temp = df.groupby("LeagueIndex")["APM"].mean()
    fig = px.line(temp,y="APM", title ="APM en fonction du LeagueIndex")
    plot1_html = fig.to_html()
               
    return plot1_html

def UniqueHotkeys():  

    temp = df.groupby("LeagueIndex")["UniqueHotkeys"].mean()
    fig = px.line(temp,y="UniqueHotkeys", title ="UniqueHotkeys en fonction du LeagueIndex")
    plot1_html = fig.to_html()
               
    return plot1_html

def HoursPerWeek():  
    
    temp = df.groupby("LeagueIndex")["HoursPerWeek"].mean()
    fig = px.line(temp,y="HoursPerWeek", title ="HoursPerWeek en fonction du LeagueIndex")
    plot1_html = fig.to_html()
               
    return plot1_html

def ActionLatency():  
    
    temp = df.groupby("LeagueIndex")["ActionLatency"].mean()
    fig = px.line(temp,y="ActionLatency", title ="ActionLatency en fonction du LeagueIndex")
    plot1_html = fig.to_html()
               
    return plot1_html

def TotalMapExplored():  
    
    temp = df.groupby("LeagueIndex")["TotalMapExplored"].mean()
    fig = px.line(temp,y="TotalMapExplored", title ="TotalMapExplored en fonction du LeagueIndex")
    plot1_html = fig.to_html()
               
    return plot1_html

def index1(request):
    
    
    if(request.GET['model']=='TotalHours'):
       plot1_html = TotalHours()
    if(request.GET['model']=='APM'):
       plot1_html = APM()
    if(request.GET['model']=='UniqueHotkeys'):
       plot1_html = UniqueHotkeys()
    if(request.GET['model']=='HoursPerWeek'):
       plot1_html = HoursPerWeek()
    if(request.GET['model']=='ActionLatency'):
       plot1_html = ActionLatency()
    if(request.GET['model']=='TotalMapExplored'):
       plot1_html = TotalMapExplored()       
       
    context = {'plot1_html': plot1_html
               }
    
    return render(request,'templates1.html',context)

def Age2():

    temp = df.groupby(['Age','LeagueIndex']).mean()
    fig = px.scatter(temp, x=df["Age"].head(1000), y=df["APM"].head(1000), color=df["LeagueIndex"].head(1000), 
                 height=700, hover_name= df["LeagueIndex"].head(1000), log_x=True, log_y=True, 
                 title='Nombre APM en fonction de AGE des 1000 premieres lignes de LeagueIndex',
                 color_discrete_sequence=px.colors.qualitative.Vivid)
    fig.update_traces(textposition='top center')
    plot2_html = fig.to_html()
    
    return plot2_html

def TotalHours2():

    temp = df.groupby(['TotalHours','LeagueIndex']).mean()
    fig = px.scatter(temp, x=df["TotalHours"].head(1000), y=df["APM"].head(1000), color=df["LeagueIndex"].head(1000), 
                 height=700, hover_name= df["LeagueIndex"].head(1000), log_x=True, log_y=True, 
                 title='Nombre APM en fonction de TotalHours des 1000 premieres lignes de LeagueIndex',
                 color_discrete_sequence=px.colors.qualitative.Vivid)
    fig.update_traces(textposition='top center')
    plot2_html = fig.to_html()
    
    return plot2_html

def ActionLatency2():

    temp = df.groupby(['ActionLatency','LeagueIndex']).mean()
    fig = px.scatter(temp, x=df["ActionLatency"].head(1000), y=df["APM"].head(1000), color=df["LeagueIndex"].head(1000), 
                 height=700, hover_name= df["LeagueIndex"].head(1000), log_x=True, log_y=True, 
                 title='Nombre APM en fonction de ActionLatency des 1000 premieres lignes de LeagueIndex',
                 color_discrete_sequence=px.colors.qualitative.Vivid)
    fig.update_traces(textposition='top center')
    plot2_html = fig.to_html()
    
    return plot2_html


def index2(request):

    
    if(request.GET['model']=='Age2'):
        plot2_html = Age2()
    if(request.GET['model']=='TotalHours2'):
        plot2_html = TotalHours2()
    if(request.GET['model']=='ActionLatency2'):
        plot2_html = ActionLatency2()

       
    context = {'plot2_html': plot2_html
                }
    
    return render(request,'templates2.html',context)

