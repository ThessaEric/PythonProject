from django.urls import path
from . import views
urlpatterns = [
    path('', views.index, name = 'index'),
    path('page1', views.index01, name = 'index'),
    path('page2', views.index02, name = 'index'),
    path('variable1', views.index1, name = 'index'),
    path('variable2', views.index2, name = 'index')
    ]
